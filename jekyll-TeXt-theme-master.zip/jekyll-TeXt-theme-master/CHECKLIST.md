# CHECKLIST

- CHANGELOG

- _config.yml unchanged

- _sass/settings/_colors.scss use default color theme